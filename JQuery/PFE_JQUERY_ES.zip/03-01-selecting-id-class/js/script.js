$(document).ready(function() {
	$('#container').html('hola');

	$('.class1').text('elementos');
});