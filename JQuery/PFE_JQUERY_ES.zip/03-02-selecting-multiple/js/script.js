$(document).ready(function() {
	$('.class1, .class2').html('<strong>hola</strong>');	
});