$(document).ready(function() {
	//$('#container').text('<strong>hola mundo</strong>');

	//$('#container').html('<strong>hola mundo</strong>');

	//$('#container').empty();

	$('#container').attr('un-nuevo', 123);
});