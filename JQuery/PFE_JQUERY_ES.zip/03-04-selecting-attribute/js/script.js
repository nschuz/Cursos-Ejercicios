$(document).ready(function() {
	//$('input[required]').addClass('highlighted');
	//$('input[placeholder="Phone"]').addClass('highlighted');
	$('input[placeholder*="Name"]').addClass('highlighted');
});