$(document).ready(function() {
	//$('#listado li').addClass('highlighted');
	$('#listado > li').addClass('highlighted');
});