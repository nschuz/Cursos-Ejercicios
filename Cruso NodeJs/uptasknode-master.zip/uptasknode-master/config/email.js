module.exports = {
    user: '',
    pass: '', 
    host: '',
    port: ''
}